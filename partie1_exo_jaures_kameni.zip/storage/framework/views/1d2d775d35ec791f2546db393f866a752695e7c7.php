<?php $__env->startSection('contenu'); ?>
  <br>
	<div class="col-sm-offset-4 col-sm-4">
		<div class="panel panel-primary">
			<div class="panel-heading"><?php echo e($sondage['question']); ?></div>
			<div class="panel-body"> 
				<p>Merci d'avoir participé à ce sondage. Voici les résultats actuels :</p>

			 	<!-- Balayage de tous les résultats -->
				<?php for($i = 0; $i < count($sondage['reponses']); $i++): ?>
					<p>
						<strong><?php echo e($sondage['reponses'][$i]); ?></strong> : <?php echo e($resultats[$i]); ?>

						<?php if($resultats[$i] > 1): ?> votes	<?php else: ?> vote	<?php endif; ?>
					</p>
					<div class="progress">
						<?php $pourcentage = number_format($resultats[$i] / array_sum($resultats) * 100) ?>
					  <div class="progress-bar progress-bar-success" style="width: <?php echo e($pourcentage); ?>%;">
					  	<?php echo e($pourcentage); ?> %
					  </div>
					</div> 					
				<?php endfor; ?>
				<!-- Fin du balayage -->

			</div>
		</div>

		<!-- Retour -->
		<?php echo link_to('sondage', 'Retour Accueil', ['class' => 'btn btn-primary']); ?>

		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>