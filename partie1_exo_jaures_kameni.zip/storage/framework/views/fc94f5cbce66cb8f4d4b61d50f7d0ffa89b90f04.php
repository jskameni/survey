<?php $__env->startSection('contenu'); ?>
  <br>
	<div class="col-sm-offset-4 col-sm-4">
		<div class="panel panel-primary">
			<div class="panel-heading"><?php echo $sondage['question']; ?></div>
			<div class="panel-body"> 

				<!-- Affichage message d'erreur éventuel -->
				<?php if(session('error')): ?>
					<div class="alert alert-danger"><?php echo session('error'); ?></div>
				<?php endif; ?>

				<!-- Formulaire de vote -->
				<?php echo Form::open(['url' => 'sondage/' . $nom]); ?>

					<div class="form-group <?php echo $errors->has('email') ? 'has-error' : ''; ?>">
						<?php echo Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'Votre email']); ?>

						<?php echo $errors->first('email', '<small class="help-block">:message</small>'); ?>

					</div>
					<?php foreach($sondage['reponses'] as $index => $reponse): ?>
						<div class="radio">
	  					<label>
	  						<?php echo Form::radio('options', $index, $index === 0); ?><?php echo $reponse; ?>

							</label>
						</div>
					<?php endforeach; ?>
					<?php echo Form::submit('Envoyer !', ['class' => 'btn btn-info pull-right']); ?>

				<?php echo Form::close(); ?>

				<!-- Fin du formulaire -->

			</div>
		</div>

		<!-- Bouton de retour à la page précédente -->
		<a href="javascript:history.back()" class="btn btn-primary">
			<span class="glyphicon glyphicon-circle-arrow-left"></span> Retour
		</a>
		
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>